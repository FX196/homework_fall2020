I used the configurations provided in the PDF for the homework and ran in colab.
